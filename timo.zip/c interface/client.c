#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>


	int main() {

//create socket
	int sock;
	sock= socket(AF_INET,SOCK_STREAM,0);

//specify the address of the server to which you are connecting
	struct sockaddr_in server_address;
	server_address.sin_family = AF_INET;
	server_address.sin_port = htons(9999);
	server_address.sin_addr.s_addr = INADDR_ANY;
	
//connect to server
	int connection=connect(sock, (struct sockaddr *) &server_address, sizeof(server_address));

//receiving server data
	 char username[10000]="Enter your username\n";
	printf("%s",username);
	fgets(username,1023,stdin);
	send(sock, username, sizeof(username),0);
	
	char password[10000]="Enter your password\n";
	printf("%s",password);
	fgets(password,1023,stdin);
	send(sock, password, sizeof(password),0);
        
       ;
        
        char feedback1[10000];
	recv(sock, &feedback1, sizeof(feedback1),0);
	printf("%s",feedback1);

	char feedback2[10000];
	fgets(feedback2,1023,stdin);
	send(sock, feedback2, sizeof(feedback2),0);
        char final[10000];
	recv(sock, &final, sizeof(final),0);
	 
    puts("\n\ndata saved to file.\nWait for your approval within 24hrs if not its been denied call administrator ");

	close(sock);

	return 0;
}
