<?php


$mysqli = mysql_connect("localhost", "root", "") ;
$db=mysql_select_db("test");

$filedub="SACCOSYSTEM.txt";
$open =fopen($filedub,"r");
$size=filesize($filedub);
$read=fread($open,$size);

echo $read;
print_r(explode(" ",$read));
$ex= explode(" ",$read);

$c=count($ex);
for ($i=0; $i < $c; $i++)
 { 
			$ex1=explode("\n", $ex[$i]);
		if (strcmp($ex1[0], "contribution")==0)
		 {
			print_r($ex1);
			echo "<br/>";
			 $result = mysql_query("INSERT into pendingtable values ('$ex1[1]','$ex1[2]','$ex1[3]','$ex1[4]')");
			if($result=true)
			{echo'done';}
		}
		}
		


	
	fclose($open);




?>
