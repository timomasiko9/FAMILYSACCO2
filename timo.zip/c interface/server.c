#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h> 
#include <mysql/mysql.h>

static char *host="localhost";
static char *username="root";
static char *password="";
static char *dbname="tester";
static char *unix_socket=NULL;
unsigned int port=0;
unsigned int flag=0;

int main(){
        MYSQL *start;
	MYSQL_RES *stop;
	MYSQL_ROW rows;
	start=mysql_init(NULL);


	if(!mysql_real_connect(start, host, username, password, dbname, port, unix_socket, flag)){
	fprintf(stderr, "\nError: %s [%d]\n",mysql_error(start), mysql_errno(start));
	exit(1);
}
//server socket 
	char message[300]= "\nYour operation is successful.";
	int server_socket,true=1;
	server_socket=socket(AF_INET, SOCK_STREAM, 0);
	setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &true, sizeof(int));

	struct sockaddr_in client;
	struct sockaddr_in server;
	server.sin_family= AF_INET;
	server.sin_port = htons(9999);
	server.sin_addr.s_addr = INADDR_ANY;
	
  if( bind(server_socket,(struct sockaddr *)&server , sizeof(server )) < 0)
    {
        //print the error message
        perror("bind failed. Error");
        return 1;
    }
	

	listen(server_socket, 100);
       //Accept and incoming connection
    puts("\t\tWaiting for incoming connections...");
      while (1){
	int c = sizeof(struct sockaddr_in);
	int client_socket;
	client_socket=accept(server_socket, (struct sockaddr *) &client, &c);
	
	
	char username[1000];
	recv(client_socket,username,1000,0);
	printf("%s",username);
	 char passwordi[1000];
    recv(client_socket, passwordi, sizeof(password),0);
    printf("%s",passwordi);
	
	mysql_query(start,"select * Member where Member.UserName='username'");
	stop=mysql_store_result(start);
	rows=mysql_fetch_row(stop);
	if(strcmp(rows[4],passwordi)==0)
	{
	

	char start[]="\n Enter command to proceed:\nPlease  follow the COMMAND format during entry\n1: contribution,name,amount,date,receipt no.\n2: loanrequest,LoanID,LoanAmount,MemberID\n3: idea,idea name,person name, description,date\n4: loan repayment,name,amount,date\ncontributioncheck\n";
	send(client_socket, start, sizeof(start),0);
        

       char fed1[1000];
	recv(client_socket,fed1,1000,0);


       

	send(client_socket, message, sizeof(message),0);
       
        char q = strtok(fed1, " "); //Break up string
              /* while(q){
			result = realloc(result, sizeof(char *)* ++space);
			if(result == NULL){
			exit(-1);
				}
				result[space-1] = q;
				q = strtok(NULL, " ");
			}

			result = realloc(result, sizeof(char*)*(space + 1));
			result[space] = 0;
			for(i = 0; i < (space + 1); ++i){
				printf("result[%d]=%s\n", i, result[i]);
			}*/
//Determine if command is a "check"
			
			 if((strcmp(fed1,"LoanRequest")) == 0){
				mysql_query(start, "insert into LoanRequest values ('q[1]','q[2]','q[3]')");
				printf("done");
			}
			
			  else if((strcmp(fed1, "contributioncheck")) == 0){
				retrieve_id = mysql_fetch_assoc(mysql_query(start, "SELECT MemberID FROM Member WHERE Member.UserName='username' "));
				id = retrieve_id[1];
				final = mysql_fetch_assoc(mysql_query(start, "SELECT contribution FROM Member WHERE MemberID = id"));
				send(client_socket, final["contribution"], sizeof(final["contribution"]), 0);
}
	    /*       
			  else if((strcmp(buff, key_three)) == 0){
				retrieve_id = mysql_fetch_assoc(mysql_query(conn, "SELECT member_id FROM members WHERE members.username= result[2]"));
				id = retrieve_id[member_id];
				content = mysql_fetch_assoc(mysql_query(conn, "SELECT loan_status FROM loan WHERE member_id = id"));
				send(accfd, content["loan_status"], sizeof(content["loan_status"]), 0);
			 } else if((strcmp(buff, key_four)) == 0){
				retrieve_id = mysql_fetch_assoc(mysql_query(conn, "SELECT member_id FROM members WHERE members.username= result[2]"));
				id = retrieve_id[member_id];
				content = mysql_fetch_assoc(mysql_query(conn, "SELECT repayment_amount remaining_amount FROM repayment_details WHERE member_id = id"));
				send(accfd, content["repayment_amount"], sizeof(content["repayment_amount"]), 0);
				send(accfd, content["remaining_amount"], sizeof(content["remaining_amount"]), 0);
			 } else {

        
	*/
	//file creation
	FILE *ti;
	ti=fopen("SACCOSYSTEM.txt","a");
	printf("Command received.PENDING state... ");
	fprintf(ti,"%s\n", fed1);
        fclose(ti);
        
    }
	close(server_socket);

	return 0;
}

}
