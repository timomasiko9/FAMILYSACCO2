 	<?php	
 	//connection variables
$host = 'localhost';
$user = '';
$password = '';

//create mysql connection
   $my = mysql_connect($host,$user,$password);

   $db=mysql_select_db("test");
	echo "<h1>FAMILY SACCO</h1>";
	echo "<h3>CONTRIBUTION(S) IN PENDING STATE</h3>";

	$from = "select * from pendingtable";
	$vo = mysql_query($from);
		  if(mysql_num_rows($vo) > 0){
	   while($fetch = mysql_fetch_row($vo))
	   {

		echo 'Name:'. $fetch[0].'<br/>';
		echo 'Amount:'. $fetch[1].'<br/>';
		echo 'Date:'. $fetch[2].'<br/>';
		echo 'Receipt number:'. $fetch[3].'';

	echo "<br/>";

	echo '<form action="allow.php" method="POST">';
		echo '<input type="hidden" name="receiptno" value="$fetch[3]">';
		echo '<input type="hidden" name="approve" value="yes">';
		echo '<input type="submit" value="APPROVE">';
	echo '</form>';

		echo '<form method="POST" action="allow.php">';
			echo '<input type="hidden" name="receiptno" value="$fetch[3]">';
			echo '<input type="hidden" name="deny" value="no">';
			echo '<input type="submit" value="DENY">';
		echo '</form>';

		if(isset($_POST['deny'])) {
	
	$in="insert into denied values ('$fetch[0]','$fetch[1]','$fetch[2]','$fetch[3]')";
	$run=mysql_query($in);

	if($run) {

	$at="delete from pendingtable where receiptno='$receiptno'";
	$tf=mysql_query($at);

}

	}
		if (isset($_POST['approve'])) {

	$po="insert into CONTRIBUTIONS values ('$fetch[0]','$fetch[1]','$fetch[2]','$fetch[3]')";
	$pot=mysql_query($po);

		if($pot){
	$del="delete from CONTRIBUTIONS where ReceiptNumber='$receiptno'";
	$ete=mysql_query($del);

}
	}
}

}
?>
