<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/carousel.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  </head>
<body>

<?php
// remove all session variables
session_unset(); 

// destroy the session 
session_destroy(); 

echo "<a href=\"index.php\" class=\"btn btn-success\" role=\"button\">Click Here if not redirected.</a>";
 
//redirect to login  page
echo "<script>location='index.php'</script>";
?>

</body>
</html>