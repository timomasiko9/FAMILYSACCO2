 	<?php	
 	//connection variables
$host = 'localhost';
$user = '';
$password = '';

//create mysql connection
   $my = mysql_connect($host,$user,$password);

   $db=mysql_select_db("test");
	echo "<h1>FAMILY SACCO</h1>";
	echo "<h3>CONTRIBUTION(S) IN PENDING STATE</h3>";

	$a = "select * from pendingtable";
	$b = mysql_query($a);

	$c = mysql_num_rows($b);
	
	$name=$_POST['name'];
	$amount=$_POST['amount'];
	$date=$_POST['date'];
	$receiptno=$_POST['receiptno'];


	for ($d = 0 ; $d < $c ; ++$d) {

		$fetch = mysql_fetch_row($b);

		echo 'Name:'. $fetch[0].'<br/>';
		echo 'Amount:'. $fetch[1].'<br/>';
		echo 'Date:'. $fetch[2].'<br/>';
		echo 'Receipt number:'. $fetch[3].'';

	echo "<br/>";

	echo <<<_END
	 <form action="allow2.php" method="POST">
	 		<input type="hidden" name="name" value="$fetch[0]">
	 		<input type="hidden" name="amount" value="$fetch[1]">
	 		<input type="hidden" name="date" value="$fetch[2]">
			<input type="hidden" name="receiptno" value="$fetch[3]">
			<input type="submit" value="APPROVE" name="approve">
			<input type="submit" value="DENY" name="deny">
	 </form>
_END;
}
		if(isset($_POST['deny'])) {
	
	$e="delete from pendingtable where ReceiptNumber='$receiptno'";
	$f=mysql_query($e);

}

		if(isset($_POST['deny'])) {
			echo $name;
			echo $amount;
			echo $date;
			echo $receiptno;

	$g="insert into deniedtable values ('$name','$amount','$date','$receiptno')";
	$h=mysql_query($g);
}
		if (isset($_POST['approve'])) {

	$k="delete from pendingtable where ReceiptNumber='$receiptno'";
	$l=mysql_query($k);
}

		if(isset($_POST['approve'])) {
			echo $name;
			echo $amount;
			echo $date;
			echo $receiptno;

	$i="insert into CONTRIBUTIONS values ('$name','$amount','$date','$receiptno')";
	$j=mysql_query($i);

	}

?>
