 <?php
	$init = mysqli_connect("localhost","root","","tester");
		if(mysqli_connect_error()){
			trigger_error('Connection Failed');
		}
	
		session_start();
		if(!isset($_SESSION['id'])){
			header("location: index.php");
			exit;
	    }
		
	function name($init,$id){
		$resultset = "";
		$result = mysqli_query($init,"SELECT FirstName FROM member WHERE MemberID = '$id' ");
		while($row = mysqli_fetch_array($result)){
        $resultset = $row['FirstName'];
		}
	return $resultset;
	} 
	
	function highestContribution($init){
		$highest = 0;
		$total = 0;
		$result = mysqli_query($init,"SELECT MemberID FROM member");
		while($row = mysqli_fetch_array($result)){
			$id = $row['MemberID'];
		$result1 = mysqli_query($init,"SELECT * FROM contributions where MemberID = '$id'");
			while($row1 = mysqli_fetch_array($result1)){
			$total+=$row1['Amount'];	
			}
			if($total > $highest){
				$highest = $total;
			}
			else{
				$total = 0;
				continue;
			}
			$total = 0;
		}
		return $highest;
	}
?>