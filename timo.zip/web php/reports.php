<?php 
include "functions.php";
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>SACCO</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />


    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>

    
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" /> 
    
    <link rel="stylesheet" href="css/style.css">
    
    
    
    <style>.card {
    /* Add shadows to create the "card" effect */
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
    transition: 0.3s;
}

/* On mouse-over, add a deeper shadow */
.card:hover {
    box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

/* Add some padding inside the card container */
.container {
    padding: 2px 16px;
}
        
    </style>
    

</head>
<body>

<div class="wrapper">
    <div style="background-color:#FFCE00;" class="sidebar">  
    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper" style="font-family:open sans;">
            <div class="logo">
                <a href="#"  style="font-family:open sans; color:white" >
                    <h3>menu</h3>
                </a>
            </div>

            <ul style="font-family:open sans;" class="nav">
                <li style="font-family:open sans;" class="active">
                    <a href="dashboard.php">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a><a href="reports.php">Reports</a>
                      <a href="contributions.php">Contributions</a>
					  <a href="sample2.php">Add Member</a>
                     

                    
                </li>
                

            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Sacco Family 1</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                               <!-- <i class="fa fa-dashboard"></i>-->
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        
                         <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                     Hello! <?php echo $_SESSION['user'];?>
                                    <b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#"><?php echo $_SESSION['user'];?></a></li>
                                <li class="divider"></li>
                                <li><a href="logout.php">Log Out</a></li>
                              </ul>
                        </li>


                    </ul>
                </div>
            </div>
        </nav>


<div class="content">
        
<!--List of loans 1-->            
<a href="#" class="modal-trigger" data-modal="modal-name">List of Loans pending approval</a> <!-- Trigger Modal. -->
        
        <!-- Modal -->
<div class="modal" id="modal-name">
  <div class="modal-sandbox"></div>
  <div class="modal-box">
    <div class="modal-header">
      <div class="close-modal">&#10006;</div> 
      <h1>Pending Approvals</h1>
    </div>
    <div class="modal-body">
	  <?php 
$output = '';
$query = "select * from pendingtable";
$result = mysqli_query($init,$query);
$output .= '<div>'
          . '<table style="border-radius:4px;border:1px solid;margin-bottom:20px;">'
            . '<tr style="text-align:center;border:1px solid;">'
              . '<th width="25%" style="text-align:center;border:1px solid;" >Person Name</th>'
              . '<th width="25%" style="text-align:center;border:1px solid;">Amount</th>'
              . '<th width="25%" style="text-align:center;border:1px solid;">Date</th>'
              . '<th width="25%" style="text-align:center;border:1px solid;">&nbsp;Receipt Number&nbsp;</th>'
            . '<tr/>';
if(mysqli_num_rows($result) > 0){
      while($row=mysqli_fetch_array($result)) {
	$output .= '<tr style="border:1px solid;">'
                .  '<td style="text-align:center;border:1px solid;">'.$row['PersonName'].'</td>'
                .  '<td style="text-align:center;border:1px solid;">'.$row['Amount'].'</td>'
                .  '<td style="text-align:center;border:1px solid;">'.$row['Date'].'</td>'
                .  '<td style="text-align:center;border:1px solid;">'.$row['ReceiptNumber'].'</td>'
                . '</tr>';
  }	
}
$output.= '</table>'
        .  '</div>'; 
echo $output;   
?>
      <br />
      <button class="close-modal">Close!</button>
    </div>
  </div>
</div><br><br><br><br>
        
        
        
<!--list of contributions 2-->
        
         
            <a href="#" class="modal-trigger" data-modal="modal-name1">List Of Contributions</a> <!-- Trigger Modal. -->
        
        <!-- Modal -->
<div class="modal" id="modal-name1">
  <div class="modal-sandbox"></div>
  <div class="modal-box">
    <div class="modal-header">
      <div class="close-modal">&#10006;</div> 
      <h1>Contibutions </h1>
    </div>
    <div class="modal-body">
      <?php 
$output1 = '';
$query = "select * from contributions";
$result = mysqli_query($init,$query);
$output1 .= '<div>'
          . '<table style="border-radius:4px;border:1px solid;margin-bottom:20px;">'
            . '<tr style="text-align:center;border:1px solid;">'
              . '<th width="25%" style="text-align:center;border:1px solid;" >FirstName</th>'
			  . '<th width="25%" style="text-align:center;border:1px solid;" >LastName</th>'
              . '<th width="25%" style="text-align:center;border:1px solid;">Amount</th>'
              . '<th width="25%" style="text-align:center;border:1px solid;">Date</th>'
              . '<th width="25%" style="text-align:center;border:1px solid;padding:0px 5px 0px 5px">Receipt Number</th>'
			  . '<th width="25%" style="text-align:center;border:1px solid;" >&nbsp;MemberID&nbsp;</th>'
            . '<tr/>';
if(mysqli_num_rows($result) > 0){
      while($row=mysqli_fetch_array($result)) {
	$output1 .= '<tr style="border:1px solid;">'
                .  '<td style="text-align:center;border:1px solid;">'.$row['FirstName'].'</td>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['LastName'].'</th>'
                .  '<td style="text-align:center;border:1px solid;">'.$row['Amount'].'</td>'
                .  '<td style="text-align:center;border:1px solid;">'.$row['Date'].'</td>'
                .  '<td style="text-align:center;border:1px solid;">'.$row['RecieptNumber'].'</td>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['MemberID'].'</td>'
                . '</tr>';
  }	
}
$output1.= '</table>'
        .  '</div>'; 
echo $output1;   
?>
      <br />
      <button class="close-modal">Close!</button>
    </div>
  </div>
</div> <br><br> <br><br>
        
    
    
    
     <!--memebrs defaulting from loans-->
            <a href="#" class="modal-trigger" data-modal="modal-name3"> Members defaulting loans</a> <!-- Trigger Modal. -->
        
        <!-- Modal -->
<div class="modal" id="modal-name3">
  <div class="modal-sandbox"></div>
  <div class="modal-box">
    <div class="modal-header">
      <div class="close-modal">&#10006;</div> 
      <h1>Members Defaulting Loans</h1>
    </div>
    <div class="modal-body">
      <?php 
$output1 = '';
$query = "select * from loan";
$result = mysqli_query($init,$query);
$output1 .= '<div>'
          . '<table style="border-radius:4px;border:1px solid;margin-bottom:20px;">'
            . '<tr style="text-align:center;border:1px solid;">'
              . '<th width="25%" style="text-align:center;border:1px solid;" >Loan ID</th>'
			  . '<th width="25%" style="text-align:center;border:1px solid;" >Loan Amount</th>'
              . '<th width="25%" style="text-align:center;border:1px solid;">Loan Date</th>'
			  . '<th width="25%" style="text-align:center;border:1px solid;">MemberID</th>'
            . '<tr/>';
if(mysqli_num_rows($result) > 0){
      while($row=mysqli_fetch_array($result)) {
		  $name = name($init,$row['MemberID']);
	$output1 .= '<tr style="border:1px solid;">'
                .  '<td style="text-align:center;border:1px solid;">'.$row['LoanID'].'</td>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['LoanAmount'].'</th>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['LoanDate'].'</th>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['MemberID'].'</th>'
                
                . '</tr>';
  }	
}
$output1.= '</table>'
        .  '</div>'; 
echo $output1;   
?>
      <br />
      <button class="close-modal">Close!</button>
    </div>
  </div>
</div><br><br><br><br>
    
    
    
    <!--best & worst performing business idea--> 
            <a href="#" class="modal-trigger" data-modal="modal-name4">Business Ideas</a> <!-- Trigger Modal. -->
        
        <!-- Modal -->
<div class="modal" id="modal-name4">
  <div class="modal-sandbox"></div>
  <div class="modal-box">
    <div class="modal-header">
      <div class="close-modal">&#10006;</div> 
      <h1>Business Ideas</h1>
    </div>
    <div class="modal-body">
            <?php 
$output1 = '';
$query = "select * from investmentidea";
$result = mysqli_query($init,$query);
$output1 .= '<div>'
          . '<table style="border-radius:4px;border:1px solid;margin-bottom:20px;">'
            . '<tr style="text-align:center;border:1px solid;">'
              . '<th width="25%" style="text-align:center;border:1px solid;" >Initial Price</th>'
			  . '<th width="25%" style="text-align:center;border:1px solid;" >Idea Name</th>'
              . '<th width="25%" style="text-align:center;border:1px solid;">Member</th>'
            . '<tr/>';
if(mysqli_num_rows($result) > 0){
      while($row=mysqli_fetch_array($result)) {
		  $name = name($init,$row['MemberID']);
	$output1 .= '<tr style="border:1px solid;">'
                .  '<td style="text-align:center;border:1px solid;">'.$row['InitialPrice'].'</td>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['IdeaName'].'</th>'
                .  '<td style="text-align:center;border:1px solid;">'.$name.'</td>'
                . '</tr>';
  }	
}
$output1.= '</table>'
        .  '</div>'; 
echo $output1;   
?>
      <br />
      <button class="close-modal">Close!</button>
    </div>
  </div>
</div><br><br><br><br>
    
    
    
    
    <!--Distribution of benefits--> 
            <a href="#" class="modal-trigger" data-modal="modal-name7">Distribution of benefits</a> <!-- Trigger Modal. -->
        
        <!-- Modal -->
<div class="modal" id="modal-name7">
  <div class="modal-sandbox"></div>
  <div class="modal-box">
    <div class="modal-header">
      <div class="close-modal">&#10006;</div> 
      <h1>Benefits</h1>
    </div>
    <div class="modal-body">
      <p><?php 
$output1 = '';
$query = "select * from benefits";
$result = mysqli_query($init,$query);
$output1 .= '<div>'
          . '<table style="border-radius:4px;border:1px solid;margin-bottom:20px;">'
            . '<tr style="text-align:center;border:1px solid;">'
              . '<th width="25%" style="text-align:center;border:1px solid;" >MemberID</th>'
			  . '<th width="25%" style="text-align:center;border:1px solid;" >Shares</th>'
              . '<th width="25%" style="text-align:center;border:1px solid;">BenefitAmount</th>'
			  . '<th width="25%" style="text-align:center;border:1px solid;">BenefitID</th>'
			  
            . '<tr/>';
if(mysqli_num_rows($result) > 0){
      while($row=mysqli_fetch_array($result)) {
	$output1 .= '<tr style="border:1px solid;">'
                .  '<td style="text-align:center;border:1px solid;">'.$row['MemberID'].'</td>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['Shares'].'</th>'
                .  '<td style="text-align:center;border:1px solid;">'.$row['BenefitAmount'].'</td>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['BenefitID'].'</td>'
				
                . '</tr>';
  }	
}
$output1.= '</table>'
        .  '</div>'; 
echo $output1;   
?> </p>
      <br />
      <button class="close-modal">Close!</button>
    </div>
  </div>
</div> <br><br><br><br>
    
    
    
    
    
            <a href="#" class="modal-trigger" data-modal="modal-name6">List Of Members</a> <!-- Trigger Modal. -->
        
        <!-- Modal -->
<div class="modal" id="modal-name6">
  <div class="modal-sandbox"></div>
  <div class="modal-box">
    <div class="modal-header">
      <div class="close-modal">&#10006;</div> 
      <h1>List of Members</h1>
    </div>
    <div class="modal-body">
      <p>  <?php 
$output1 = '';
$query = "select * from member";
$result = mysqli_query($init,$query);
$output1 .= '<div>'
          . '<table style="border-radius:4px;border:1px solid;margin-bottom:20px;">'
            . '<tr style="text-align:center;border:1px solid;">'
              . '<th width="25%" style="text-align:center;border:1px solid;" >MemberID</th>'
			  . '<th width="25%" style="text-align:center;border:1px solid;" >First Name</th>'
              . '<th width="25%" style="text-align:center;border:1px solid;">Last Name</th>'
			  . '<th width="25%" style="text-align:center;border:1px solid;">User Name</th>'
			  . '<th width="25%" style="text-align:center;border:1px solid;">&nbsp;Password&nbsp;</th>'
			  . '<th width="25%" style="text-align:center;border:1px solid;">&nbsp;Contribution&nbsp;</th>'
			  
			  
            . '<tr/>';
if(mysqli_num_rows($result) > 0){
      while($row=mysqli_fetch_array($result)) {
	$output1 .= '<tr style="border:1px solid;">'
                .  '<td style="text-align:center;border:1px solid;">'.$row['MemberID'].'</td>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['FirstName'].'</th>'
                .  '<td style="text-align:center;border:1px solid;">'.$row['LastName'].'</td>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['UserName'].'</td>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['Password'].'</td>'
				.  '<td style="text-align:center;border:1px solid;">'.$row['contribution'].'</td>'
				
                . '</tr>';
  }	
}
$output1.= '</table>'
        .  '</div>'; 
echo $output1;   
?></p>
      <br />
      <button class="close-modal">Close!</button>
    </div>
  </div>
</div><br><br><br>    
        
        
</div>
    
    
    
    
    
    

<!-- Aditional Styles -->
<link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">
  <script src='jquery.min.js'></script>

    <script src="js/index.js"></script>

</div>

    </div>


        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="#">
                                Home
                            </a>
                        </li>

                    </ul>
                </nav>
                <!--<p class="copyright pull-right">
                    &copy; 2016 <a href="http://www.creative-tim.com">Creative Tim</a>, made with love for a better web
                </p> -->
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>
