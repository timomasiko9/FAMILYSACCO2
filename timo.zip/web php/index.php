<?php
session_start();
	$init = mysqli_connect("localhost","root","","tester");
	if(mysqli_connect_error()){
		trigger_error('Connection Failed');
	}
		
if(isset($_POST['submit'])){
$resultset = "";
/* User login process, checks if user exists and password is correct */

// Escape email to protect against SQL injections
$username = mysqli_real_escape_string($init,trim($_POST['username']));
$password = mysqli_real_escape_string($init,trim($_POST['password']));
    
$result = mysqli_query($init,"SELECT * FROM member WHERE UserName='$username' and Password = '$password' ");

    while($row = mysqli_fetch_array($result)){
        $resultset = $row;
    }
    
if (mysqli_num_rows($result) < 1){ // User doesn't exist
    header("location: index.php?login=fail");
}
else{ //user exists
    //set session and session variables
    $_SESSION['id'] = $resultset['MemberID'];
    $_SESSION['user'] = $resultset['FirstName'];
    $_SESSION['first'] = $resultset['UserName'];
    $_SESSION['last'] = $resultset['FirstName'];
    $_SESSION['contribution'] = $resultset['contribution'];
    session_write_close();
  }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Sign in Page</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">
      
    <script src="jquery-3.1.1.js" type="text/javascript"></script>
      
      <style>
body {  }
          h2 {
              text-align: center;
          }
		</style>
  </head>

  <body>
<?php
if(isset($_SESSION['id'])){
    header("location: dashboard.php");
}

else{ 
  ?> 
      <div class="container">
      <form class="form-signin" action="#" method="post">
          <h2 style="font-size: 220%; font-family:open sans;">SACCO</h2>
        <h2 class="form-signin-heading">Please sign in</h2>
        <label for="inputEmail" class="sr-only">Username</label>
        <input type="text" id="inputEmail"  name="username" class="form-control" placeholder="User Name" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
        <input class="btn btn-lg btn-primary btn-block" type="submit" name="submit" value="Sign in">
      </form>
    </div> <!-- /container -->

<?php    
}
?>
      <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
      <script src="js/ie10-viewport-bug-workaround.js"></script>
 </body>
</html>